package labBook1_2;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.ApplicationContext;

public class labBook1_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext app = new ClassPathXmlApplicationContext("spring1_2.xml");
		Employee e = (Employee) app.getBean("emp");
		SBU s = (SBU) app.getBean("sbu");
		e.setBusinessUnit(s);
		System.out.println(e);

	}

}
