package com.cg.lab1_4.DAO;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.lab1_4.dto.labBook1_4DTO;

@Component("dao")
public class labBook1_4DAOImpl implements labBook1_4DAO {
	
	Map<Integer, labBook1_4DTO> map;
	
	public labBook1_4DAOImpl() {
		// TODO Auto-generated constructor stub
		map = new HashMap<Integer, labBook1_4DTO>();
		map.put(100, new labBook1_4DTO(100, "ABC", 50000));
		map.put(101, new labBook1_4DTO(101, "DEF", 40000));
		map.put(102, new labBook1_4DTO(102, "GHI", 30000));
		map.put(103, new labBook1_4DTO(103, "JKL", 20000));
	}

	@Override
	public labBook1_4DTO getEmp(int id) {
		// TODO Auto-generated method stub
		return map.get(Integer.valueOf(id));
	}
	
}
