package com.cg.lab1_4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.lab1_4.DAO.labBook1_4DAO;
import com.cg.lab1_4.dto.labBook1_4DTO;

@Component("service")
public class labBook1_4ServiceImpl implements labBook1_4Service {
	
	@Autowired
	labBook1_4DAO dao;
	
	@Override
	public labBook1_4DTO getEmp(int id) {
		// TODO Auto-generated method stub
		return dao.getEmp(id);
	}

}
