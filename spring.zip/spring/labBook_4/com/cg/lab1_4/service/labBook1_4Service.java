package com.cg.lab1_4.service;

import org.springframework.stereotype.Component;

import com.cg.lab1_4.dto.labBook1_4DTO;

//@Component("service")
public interface labBook1_4Service {
	
	public labBook1_4DTO getEmp(int id);

}
