package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Service("service")
//@Component("sb")
public class SBU {

//	@Value("10221")
	int sbuCode;
//	@Value("Bongu")
	String sbuName;
//	@Value("Boshanam")
	String sbuHead;
	List<Employee> empList;
//	@Autowired
//	Employee e;
	
	public int getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getEmpList() {
//		empList.add(e);
//		empList.add(e);
		return empList;
	}
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	@Override
	public String toString() {
		String s = "SBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName
				+ ", sbuHead=" + sbuHead + "]\n";
		for(Employee em : getEmpList())
			s += em+"\n";
		return s;
	}
	
	

}
