package com.cg.eb.dao;

import java.util.ArrayList;

import com.cg.eb.dto.Consumers;
import com.cg.eb.except.BillException;

public interface IBillDAO {
	
	public ArrayList<Consumers> getConsumerNames() throws BillException;

	public ArrayList<Consumers> searchConsumer(long consumer_num)
			throws BillException;

}
