package com.cg.eb.service;

import java.util.ArrayList;

import com.cg.eb.dao.IBillDAO;
import com.cg.eb.dto.Consumers;
import com.cg.eb.except.BillException;

public class BillServiceImpl implements IBillService {
	
	IBillDAO billDAO;

	public BillServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public ArrayList<Consumers> getConsumerNames() throws BillException {
		// TODO Auto-generated method stub
		return billDAO.getConsumerNames();
	}

	@Override
	public ArrayList<Consumers> searchConsumer(long consumer_num) throws BillException {
		// TODO Auto-generated method stub
		return billDAO.searchConsumer(consumer_num);
	}

}
